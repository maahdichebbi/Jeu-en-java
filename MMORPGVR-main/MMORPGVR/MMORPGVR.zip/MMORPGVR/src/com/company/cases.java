package com.company;

public class cases {
    int indice ;
    char val  ;
    public cases(){
        indice = (int)Math.random();
    }
}
