package com.company;

import java.util.Scanner;

public class Menu {
    String choix ;

    public static void main(String[] args) {
        System.out.println("#####################################");
        System.out.println("##        ELEHLPTMMMORPGSVR        ##");
        System.out.println("##---------------------------------##");
        System.out.println("##        1.nouvelle partie        ##");
        System.out.println("##        2.sauvegarder            ##");
        System.out.println("##        3.reprendre partie       ##");
        System.out.println("#####################################");

        Scanner scan = new Scanner(System.in);
        if (scan.nextInt() == 1) {
            Plateau.generate() ;

        }
    }



}
