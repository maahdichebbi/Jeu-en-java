package com.company;

public class Objets extends Joueur{


    int potionS ;
    int potionEx ;
    int molotov ;

    public Objets(){

    }

    public void utiliser(){
        switch(this) {
            case potionS:
                this.blessure = "en forme ";
                break;
            case molotov:
                // code block
                break;
            default:
                // code block
        }

    }

    public void booster(){

    }






}
