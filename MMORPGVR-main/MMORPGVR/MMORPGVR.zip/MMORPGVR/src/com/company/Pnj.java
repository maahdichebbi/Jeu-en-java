package com.company;

public class Pnj {
    boolean monstre ;
    int initiative ;
    int attaque ;
    int defanse ;
    int degat ;
    int pv ;
    int xp ;
    String objets ;

    public Pnj(){

    }
    public void  dropObjets() {

    }
}
