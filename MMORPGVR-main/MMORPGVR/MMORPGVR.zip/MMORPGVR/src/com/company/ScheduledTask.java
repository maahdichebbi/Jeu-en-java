package com.company;

import java.util.TimerTask;
import java.util.Date;

// Create a class extending TimerTask
public class ScheduledTask extends TimerTask {
    Date now;
    public void run() {
        this.Pa += 1 ;
        now = new Date();                      // initialize date
        System.out.println("Time is :" + now); // Display current time
    }
}