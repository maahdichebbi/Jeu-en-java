package com.company;

import java.util.Random;
import java.util.Scanner;
import java.util.Timer;
import java.util.concurrent.ThreadLocalRandom;

public class Joueur extends Pnj {

    int force ;
    int adresse ;
    int resistance ;
    int xp ;
    int initiative ;
    int attaque ;
    int defanse ;
    int degats ;
    int Pa = 10 ;
    String blessure  ;
    String equipement ;
    String inventaire ;

    public   Joueur () {
        while ((force + adresse + resistance) != 18) {
            System.out.println("veuillez  attribuer 18 degrés au totale  ");
            Scanner scan = new Scanner(System.in);
            System.out.println("attribuer  la force");
            this.force = scan.nextInt();
            System.out.println("attribuer  la adresse");
            this.adresse = scan.nextInt();
            System.out.println("attribuer  la resistance");
            this.resistance = scan.nextInt();
        }
        System.out.println("*** personnage  créer *** ");




        }



    public void pointAction(){
        this.Pa += 1 ;
    }
    public int alea(){
        return  ThreadLocalRandom.current().nextInt(1, 6 + 1);

    }
    public void get_force (){
        System.out.println(force);
    }
    public void  attack(Pnj mob ){
        this.Pa -= 3 ;
        mob.pv -= degats - defanse ;
        xp+= 1 ;

    }

    public void xpRajout (Joueur j , Pnj mob ){
        int max = Math.max(j.xp , mob.xp);
        int min = Math.min(j.xp , mob.xp) ;
        int ratio = max / min ;
        xp += ratio;

    }
    public void deplacer(){
        this.Pa -= 2 ;
    }

    public void utiliserUnObjet(){

    }

    public void ramasser (){

    }
    public void  deposer(){

    }

    public static void main(String[] args) {

        Random rand = new Random();
        Joueur pj = new Joueur();
        System.out.println(pj.alea());
        pj.deplacer();
        System.out.println(pj.Pa);
        Timer timer;
        timer = new Timer();
        timer.schedule( pj.pointAction(), 1000, 5000);


    }
}
