package com.company;

public class equipement {
    int  armure ;
    int  casque ;
    int  arme ;

    public equipement(){


    }
    public void degats(){

    }

    public void resistance(){

    }

}
